# Copyright (c) 2022, Frappe Technologies Pvt. Ltd. and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class EmployeeFeedbackRating(Document):
	# begin: auto-generated types
	# This code is auto-generated. Do not modify anything in this block.

	from typing import TYPE_CHECKING

	if TYPE_CHECKING:
		from frappe.types import DF

		criteria: DF.Link
		parent: DF.Data
		parentfield: DF.Data
		parenttype: DF.Data
		per_weightage: DF.Percent
		rating: DF.Rating
	# end: auto-generated types

	pass
