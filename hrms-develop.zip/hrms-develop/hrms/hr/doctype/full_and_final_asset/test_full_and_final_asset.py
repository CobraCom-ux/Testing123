# Copyright (c) 2021, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

# import frappe
from hrms.tests.utils import HRMSTestSuite


class TestFullandFinalAsset(HRMSTestSuite):
	pass
